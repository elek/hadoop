---
date: 2011-03-31
title: Apache Hadoop takes top prize at Media Guardian Innovation Awards
---
<!---
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License. See accompanying LICENSE file.
-->

Described by the judging panel as a "Swiss army knife of the 21st
century", Apache Hadoop picked up the *innovator of the year* award for
having the potential to change the face of media innovations.

See [The Guardian web
site](http://www.guardian.co.uk/technology/2011/mar/25/media-guardian-innovation-awards-apache-hadoop)

